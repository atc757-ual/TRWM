const mongoose = require('mongoose');

const openingTimeSchema = new mongoose.Schema({    
    days: {type: String, required: true},
    opening:  String,
    closing:  String,
    closed: {type: Boolean, required: true}
});

const reviewSchema = new mongoose.Schema({
    author: String,
    rating: {type: Number, min: 0, max: 5, required: true},
    reviewText: String,
    createdOn: {type: Date, default: Date.now}
})

const locationSchema = new mongoose.Schema({   
    name: {type: String, required: true},
    address: String,    
    rating: {type: Number, min: 0, max: 5},
    facilities: [String],

    coords: {
        type: { type: String, default: 'Point'},
        coordinates: {type: [Number], index: '2dsphere'},
    },
    distance: String,
    openingTimes: [openingTimeSchema],
    reviews: [reviewSchema]
});


/*const homeList = (req,res) => {
    res.render('locations-list', {title: 'Loc8r - find a place to work with wifi',
        pageHeader: {title: 'Loc8r', strapline: 'Find places to work with wifi near you!'},
        locations:[{
            name: 'Starcups',
            address: '125 High Street, Reading, RG6 1PS', 
            rating: 3, 
            facilities: ['Hot drinks', 'Food', 'Premium wifi'],
            distance: '100m'},]
    });
};
const locationInfo = (req,res) => {
    res.render('location-info', {title: 'Location Info'})
};
const addReview=(req,res) => {
    res.render('location-review-form', {title: 'Add Review'})
};

module.exports = {
  homeList,
  locationInfo,
  addReview
}

*/